document.addEventListener("DOMContentLoaded", function () {

const careers = {
"AI / ML Engineer":{
description:"Build intelligent systems using Artificial Intelligence and Machine Learning.",
skills:["Python","Machine Learning","Mathematics","Data Structures","Deep Learning"],
path:"Python → Mathematics → Machine Learning → AI Projects → Portfolio"
},

"Data Scientist":{
description:"Analyze data and use statistics and machine learning to find useful insights.",
skills:["Python","Statistics","SQL","Data Visualization","Machine Learning"],
path:"Python → Statistics → SQL → Data Analysis → Projects"
},

"Software Developer":{
description:"Design, build and maintain applications, websites and digital products.",
skills:["Programming","Data Structures","Git & GitHub","Problem Solving"],
path:"Programming → Data Structures → Projects → Development → Portfolio"
},

"Cybersecurity":{
description:"Protect computers, networks and information from digital attacks.",
skills:["Networking","Linux","Cybersecurity","Ethical Hacking"],
path:"Networking → Linux → Security → Practice Labs → Certifications"
},

"Robotics Engineer":{
description:"Design intelligent machines and automated systems.",
skills:["Programming","Electronics","Robotics","Sensors","AI"],
path:"Programming → Electronics → Robotics → Projects → Advanced Systems"
},

"Cloud Engineer":{
description:"Design and manage applications and infrastructure on cloud platforms.",
skills:["Networking","Linux","Cloud Computing","DevOps","Security"],
path:"Networking → Linux → Cloud → DevOps → Projects"
}
};


// CAREER POPUP

const careerModal=document.getElementById("careerModal");

document.querySelectorAll(".career-card").forEach(card=>{

card.addEventListener("click",function(){

const data=careers[this.dataset.career];

if(!data || !careerModal)return;

document.getElementById("modalTitle").textContent=this.dataset.career;
document.getElementById("modalDescription").textContent=data.description;
document.getElementById("modalPath").textContent=data.path;

const list=document.getElementById("modalSkills");
list.innerHTML="";

data.skills.forEach(skill=>{
const li=document.createElement("li");
li.textContent=skill;
list.appendChild(li);
});

careerModal.style.display="flex";

});

});


// SKILLS POPUP

const skillModal=document.getElementById("skillModal");

document.querySelectorAll(".skill-card").forEach(card=>{

card.addEventListener("click",function(){

if(!skillModal)return;

document.getElementById("skillTitle").textContent=
this.dataset.title;

document.getElementById("skillDescription").textContent=
this.dataset.description;

document.getElementById("skillCareers").textContent=
this.dataset.careers;

const topics=document.getElementById("skillTopics");
topics.innerHTML="";

(this.dataset.topics||"Basics,Practice,Projects")
.split(",")
.forEach(topic=>{

const li=document.createElement("li");
li.textContent=topic.trim();
topics.appendChild(li);

});

skillModal.style.display="flex";

});

});


// ROADMAP POPUP

const roadmapModal=document.getElementById("roadmapModal");

const roadmapInfo=[
{
title:"Discover",
description:"Understand your interests, strengths and career goals.",
tasks:["Identify interests","Understand strengths","Explore careers","Set goals"]
},
{
title:"Learn Fundamentals",
description:"Build a strong foundation in programming and technology.",
tasks:["Learn programming","Computer fundamentals","Problem solving","Basic tools"]
},
{
title:"Develop Skills",
description:"Develop the technical and professional skills required.",
tasks:["Choose technical skills","Practice regularly","Learn industry tools","Improve communication"]
},
{
title:"Build Projects",
description:"Create real-world projects and strengthen your portfolio.",
tasks:["Choose projects","Build projects","Upload to GitHub","Create portfolio"]
},
{
title:"Launch Your Career",
description:"Prepare yourself for internships and jobs.",
tasks:["Create resume","Build professional profile","Apply for internships","Prepare interviews"]
}
];

document.querySelectorAll(".roadmap .step").forEach((step,index)=>{

step.addEventListener("click",function(e){

if(e.target.classList.contains("roadmap-check"))return;

if(!roadmapModal)return;

const data=roadmapInfo[index];

document.getElementById("roadmapTitle").textContent=data.title;
document.getElementById("roadmapDescription").textContent=data.description;

const list=document.getElementById("roadmapTasks");
list.innerHTML="";

data.tasks.forEach(task=>{
const li=document.createElement("li");
li.textContent=task;
list.appendChild(li);
});

roadmapModal.style.display="flex";

});

});


// AI TOOLS POPUP

const toolModal=document.getElementById("toolModal");

document.querySelectorAll(".ai-tool-card").forEach(card=>{

card.addEventListener("click",function(){

if(!toolModal)return;

document.getElementById("toolTitle").textContent=
this.querySelector("h3").textContent;

document.getElementById("toolDescription").textContent=
this.querySelector("p").textContent;

document.getElementById("toolUse").textContent=
"Students, developers, creators and professionals.";

toolModal.style.display="flex";

});

});


// CLOSE BUTTONS

const closeIds=[
"closeModal",
"closeSkillModal",
"closeRoadmapModal",
"closeToolModal"
];

closeIds.forEach(id=>{

const btn=document.getElementById(id);

if(btn){

btn.addEventListener("click",function(){

const modal=this.closest(".modal");

if(modal)modal.style.display="none";

});

}

});

window.addEventListener("click",function(e){

if(e.target.classList.contains("modal")){
e.target.style.display="none";
}

});


// MOBILE MENU

const menu=document.getElementById("menuBtn");
const nav=document.querySelector("nav ul");

if(menu && nav){

menu.addEventListener("click",function(){
nav.classList.toggle("active");
});

nav.querySelectorAll("a").forEach(link=>{
link.addEventListener("click",()=>{
nav.classList.remove("active");
});
});

}


// THEME

const theme=document.getElementById("themeBtn");

if(theme){

theme.addEventListener("click",function(){

document.body.classList.toggle("light-theme");

const light=document.body.classList.contains("light-theme");

this.textContent=light?"🌙":"☀️";

localStorage.setItem("theme",light?"light":"dark");

});

if(localStorage.getItem("theme")==="light"){

document.body.classList.add("light-theme");
theme.textContent="🌙";

}

}


// CAREER SEARCH

const search=document.getElementById("careerSearch");

if(search){

search.addEventListener("input",function(){

const value=this.value.toLowerCase();

document.querySelectorAll(".career-card").forEach(card=>{

card.style.display=
card.textContent.toLowerCase().includes(value)
?""
:"none";

});

});

}


// CAREER FINDER

const find=document.getElementById("findCareerBtn");

if(find){

find.addEventListener("click",function(){

const selected=[
...document.querySelectorAll(
"#career-finder input:checked"
)
].map(x=>x.value);

const result=document.getElementById("careerResult");

if(!result)return;

if(selected.length===0){

result.innerHTML=`
<div class="result-card">
<h3>⚠️ Select an interest</h3>
<p>Choose at least one interest.</p>
</div>`;

return;

}

let career="UI/UX Designer";
let description="Design user-friendly digital products and interfaces.";
let skills="UI Design • UX Research • Creativity";

if(selected.includes("ai")){

career="AI / ML Engineer";
description="Build intelligent systems using AI and Machine Learning.";
skills="Python • Machine Learning • Mathematics • Deep Learning";

}else if(selected.includes("coding")){

career="Software Developer";
description="Design and build websites, applications and software.";
skills="Programming • Data Structures • JavaScript • Git";

}else if(selected.includes("data")){

career="Data Scientist";
description="Analyze data and discover useful insights.";
skills="Python • Statistics • SQL • Data Visualization";

}else if(selected.includes("security")){

career="Cybersecurity Specialist";
description="Protect systems, networks and information.";
skills="Networking • Linux • Cybersecurity • Ethical Hacking";

}else if(selected.includes("robotics")){

career="Robotics Engineer";
description="Design intelligent machines and automated systems.";
skills="Programming • Electronics • Robotics • AI";

}

result.innerHTML=`
<div class="result-card">
<h3>🎯 Recommended Career</h3>
<h2>${career}</h2>
<p>${description}</p>
<p><strong>Skills:</strong> ${skills}</p>
</div>`;

});

}


// SKILLS MATCHER

const match=document.getElementById("matchSkillsBtn");

if(match){

match.addEventListener("click",function(){

const skills=[
...document.querySelectorAll(
"#skills-matcher input:checked"
)
].map(x=>x.value);

const result=document.getElementById("skillsResult");

if(!result)return;

if(skills.length===0){

result.innerHTML=`
<div class="skill-result-card">
<h3>⚠️ Select some skills</h3>
<p>Choose at least one skill.</p>
</div>`;

return;

}

let careers=[];

if(skills.includes("python")||skills.includes("ml"))
careers.push("🤖 AI / ML Engineer");

if(skills.includes("python")||skills.includes("data"))
careers.push("📊 Data Scientist");

if(skills.includes("javascript"))
careers.push("💻 Software Developer");

if(skills.includes("networking")||skills.includes("security"))
careers.push("🔐 Cybersecurity Specialist");

if(skills.includes("robotics"))
careers.push("🦾 Robotics Engineer");

if(skills.includes("design"))
careers.push("🎨 UI/UX Designer");

if(careers.length===0)
careers.push("💻 Software Developer");

result.innerHTML=`
<div class="skill-result-card">
<h3>🎯 Matching Careers</h3>
<p>${careers.join("<br>")}</p>
</div>`;

});

}


// PERSONAL ROADMAP

const generate=document.getElementById("generateRoadmap");

if(generate){

generate.addEventListener("click",function(){

const career=document.getElementById("roadmapCareer").value;
const result=document.getElementById("roadmapResult");

if(!result)return;

const data={

ai:["🤖 AI / ML Engineer",
"Learn Python",
"Learn Mathematics & Statistics",
"Study Machine Learning",
"Learn Deep Learning",
"Build AI Projects",
"Create Portfolio",
"Apply for Jobs"],

data:["📊 Data Scientist",
"Learn Python",
"Learn Statistics",
"Learn SQL",
"Learn Data Analysis",
"Learn Machine Learning",
"Build Data Projects",
"Create Portfolio"],

software:["💻 Software Developer",
"Learn Programming",
"Learn Data Structures",
"Learn Web/App Development",
"Build Projects",
"Learn Git & GitHub",
"Create Portfolio",
"Apply for Jobs"],

cyber:["🔐 Cybersecurity Specialist",
"Learn Computer Fundamentals",
"Learn Networking",
"Learn Linux",
"Study Cybersecurity",
"Practice Security Labs",
"Build Projects",
"Apply for Jobs"],

robotics:["🦾 Robotics Engineer",
"Learn Programming",
"Learn Electronics",
"Study Robotics",
"Learn Sensors",
"Learn Automation",
"Build Projects",
"Create Portfolio"],

cloud:["☁️ Cloud Engineer",
"Learn Networking",
"Learn Linux",
"Study Cloud Computing",
"Learn AWS/Azure",
"Learn DevOps",
"Build Cloud Projects",
"Apply for Jobs"]

};

if(!career){

result.innerHTML=`
<div class="personal-roadmap-card">
<h3>⚠️ Choose a career</h3>
<p>Please select a career first.</p>
</div>`;

return;

}

const selected=data[career];

let html=`<div class="personal-roadmap-card">
<h3>${selected[0]}</h3>`;

selected.slice(1).forEach((step,i)=>{

html+=`
<div class="roadmap-item">
<span>STEP ${String(i+1).padStart(2,"0")}</span>
<p>${step}</p>
</div>`;

});

html+="</div>";

result.innerHTML=html;

});

}


// PROFILE

const create=document.getElementById("createProfile");

if(create){

create.addEventListener("click",function(){

const name=document.getElementById("profileName").value.trim();
const career=document.getElementById("profileCareer").value;
const goal=document.getElementById("profileGoal").value.trim();
const result=document.getElementById("profileResult");

if(!name||!career||!goal){

result.innerHTML=`
<div class="profile-card">
<h3>⚠️ Complete your profile</h3>
<p>Please enter all details.</p>
</div>`;

return;

}

localStorage.setItem("careerName",name);
localStorage.setItem("careerCareer",career);
localStorage.setItem("careerGoal",goal);

result.innerHTML=`
<div class="profile-card">
<h3>🎉 Profile Created!</h3>
<p><strong>Name:</strong> ${name}</p>
<p><strong>Career:</strong> ${career}</p>
<p><strong>Goal:</strong> ${goal}</p>
</div>`;

});

}


// PROGRESS TRACKER

const checks=document.querySelectorAll(".roadmap-check");
const fill=document.getElementById("progressFill");
const text=document.getElementById("progressText");

function updateProgress(){

if(!fill||!text||!checks.length)return;

const completed=
document.querySelectorAll(".roadmap-check:checked").length;

const total=checks.length;

const percent=
Math.round(completed/total*100);

fill.style.width=percent+"%";

text.textContent=
`${completed} of ${total} steps completed (${percent}%)`;

}

checks.forEach(check=>{
check.addEventListener("change",updateProgress);
});

updateProgress();

});